# Alif+ ikonka to‘plami

Tanlangan oq A, yashil + va to‘q ko‘k fonli dizaynning platformalarga mos raster aktivlari.

| Qayerda | Asosiy fayl | O‘lcham / tarkib |
|---|---|---|
| Brauzer | `web/favicon.ico` | 16, 24, 32, 48, 64 px, bitta ICO ichida |
| iPhone bosh ekranidagi veb-sayt | `web/apple-touch-icon.png` | 180×180, shaffofliksiz |
| PWA | `web/pwa-*.png`, `web/pwa-maskable-*.png` | 192 va 512 px, manifest bilan |
| iOS / iPadOS | `ios/AppIcon.appiconset` | 1024×1024 PNG + Contents.json |
| Eski Xcode loyihalari | `ios/AppIcon-Legacy.appiconset` | iPhone va iPad uchun 20–1024 px |
| Android | `android/res/` | mdpi–xxxhdpi, legacy, round, API 26+ adaptive |
| Google Play | `android/play-store-512.png` | 512×512, shaffofliksiz |
| Windows | `windows/Alifplus.ico` | 16, 24, 32, 48, 64, 128, 256 px |
| macOS | `macos/Alifplus.icns` | 16–1024 px; iconset va Xcode katalogi ham bor |
| Linux | `linux/hicolor/` | 16–1024 px PNG |
| Asosiy nusxalar | `master/` | 1024 px kvadrat va shaffof chetli variant |

## Brauzer / sayt
`web/` ichidagi fayllarni saytingizning public ildiziga nusxalang va `head-snippet.html` kodini `<head>` ichiga qo‘shing. Sayt ichki papkada joylashgan bo‘lsa, snippetdagi `/` bilan boshlanuvchi yo‘llarni o‘sha papkaga moslang. Manifestning `start_url`, `scope` va `id` qiymatlarini mavjud PWA loyihangizga moslang. Avvalgi manifest bo‘lsa, uni almashtirmasdan faqat icons qismini yangilang. Ikonka kesh sabab darhol yangilanmasa, qattiq qayta yuklang yoki yangi versiya nomidan foydalaning. Bu to‘plam PWA o‘rnatilishi uchun zarur bo‘ladigan sayt/HTTPS konfiguratsiyasini o‘zi yaratmaydi.

## iPhone / iPad
Xcode’dagi `Assets.xcassets` ichiga `ios/AppIcon.appiconset`ni qo‘shing. Target → General → App Icons and Launch Screen’da shu AppIcon’ni tanlang. PNG burchaklari oldindan yumaloqlanmagan va alpha kanali yo‘q: tizim shakl beradi. Eski loyiha alohida iPhone/iPad kataklarini talab qilsa, Legacy katalogidan foydalaning, ikkalasini bir vaqtda tanlamang. Bu bitmap katalogi; alohida Liquid Glass / Icon Composer `.icon` loyihasi emas.

## Android
`android/res/` tarkibini `app/src/main/res/` bilan birlashtiring. Manifestdagi mavjud `<application>`ga snippetdagi ikki atributni qo‘shing. API 26+ qurilmalar adaptive XML’dan, eskilari density PNG’lardan foydalanadi. Adaptive qatlamlar 108 dp; belgi 66 dp xavfsiz doirada saqlangan. Rangli raster foreground va alohida fon qatlami berilgan. Maxsus monochrome/themed qatlam bu to‘plamga kiritilmagan. `play-store-512.png`ni Google Play Console ikonka maydoniga yuklang; konsol previewini tekshiring.

## Windows
Loyiha ikonka sozlamasiga `windows/Alifplus.ico`ni bering. Masalan, .NET loyihasida `<ApplicationIcon>Alifplus.ico</ApplicationIcon>`; Electron kabi freymvorkda Windows build icon maydonini shu ICO’ga yo‘naltiring. PNG’ni shunchaki `.ico` deb qayta nomlash kerak emas: berilgan fayl haqiqiy ko‘p o‘lchamli ICO.

## macOS
Xcode loyihasi uchun `macos/AppIcon.appiconset`ni asset katalogiga qo‘shing. Oddiy app bundle yig‘ishda `Alifplus.icns`ni `App.app/Contents/Resources/`ga qo‘ying va `Info.plist`dagi `CFBundleIconFile`ni `Alifplus.icns`ga yo‘naltiring. Imzolangan ilovada ikonka build vaqtida qo‘shilishi va keyin ilova qayta imzolanishi kerak.

## Linux
`hicolor` tarkibini `~/.local/share/icons/hicolor/`ga o‘rnating. `.desktop` faylda `Icon=alifplus`dan foydalaning; berilgan namunada `Exec` yo‘lini almashtiring.

## Tekshiruv
PNG sarlavhalari va o‘lchamlari, iOS PNG’larida alpha yo‘qligi, ICO ichidagi rasmlar, ICNS tuzilishi, JSON/XML havolalari va ZIP yaxlitligi tekshirildi. `preview.png`da chapdan: kvadrat mobil asos, Android yumaloq maskasi, kompyuter ikonkasi; pastda 16/32/48/64 px faviconlar. Yakuniy ilova ichida build yoki do‘konga yuklash amalga oshirilmagan.

Formatlarga moslashda belgi va asosiy ranglar saqlangan; rasmiy vektor SVG emas, raster PNG asosidan eksport qilingan. Ikonka fayllari dasturga avtomatik ulanmaydi: yuqoridagi mos platforma qadamini bajaring.

## Manbalar
- https://developer.apple.com/documentation/xcode/configuring-your-app-icon
- https://developer.apple.com/design/human-interface-guidelines/app-icons
- https://developer.android.com/develop/ui/compose/system/icon_design_adaptive
- https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Manifest/Reference/icons
