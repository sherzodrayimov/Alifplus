#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <UIAutomation.h>
#include <atomic>
#include <wchar.h>
static std::atomic<bool> running{true}, safe{false};
static std::atomic<HWND> foreground{nullptr}, focused{nullptr};
static std::atomic<unsigned long> revision{0};
static std::atomic<ULONGLONG> checkedAt{0};
static HANDLE worker;
static HWINEVENTHOOK focusHook;
static void CALLBACK focusChanged(HWINEVENTHOOK,DWORD,HWND,LONG,LONG,DWORD,DWORD) { safe=false; ++revision; }
static DWORD WINAPI monitor(LPVOID) {
    CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    IUIAutomation *uia=nullptr;
    CoCreateInstance(CLSID_CUIAutomation,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&uia));
    IUIAutomationElement *last=nullptr;
    while (running) {
        const auto generation=revision.load();
        HWND fg=GetForegroundWindow();
        GUITHREADINFO info={sizeof(info)};
        GetGUIThreadInfo(GetWindowThreadProcessId(fg,nullptr),&info);
        IUIAutomationElement *element=nullptr;
        BOOL password=TRUE, active=FALSE;
        CONTROLTYPEID type=0;
        bool ok=false;
        if (uia && SUCCEEDED(uia->GetFocusedElement(&element)) && element) {
            BOOL same=FALSE;
            if (last) uia->CompareElements(last,element,&same);
            if (!same) { safe=false; ++revision; }
            ok=SUCCEEDED(element->get_CurrentIsPassword(&password)) && !password &&
               SUCCEEDED(element->get_CurrentIsEnabled(&active)) && active &&
               SUCCEEDED(element->get_CurrentControlType(&type)) &&
               (type==UIA_EditControlTypeId || type==UIA_DocumentControlTypeId || type==UIA_ComboBoxControlTypeId);
            if (last) last->Release(); last=element;
        }
        WCHAR className[64]={0};
        if (info.hwndFocus) GetClassNameW(info.hwndFocus,className,64);
        if ((!_wcsicmp(className,L"Edit") || !_wcsnicmp(className,L"RichEdit",8)) &&
            (GetWindowLongPtrW(info.hwndFocus,GWL_STYLE)&ES_PASSWORD)) ok=false;
        foreground=fg; focused=info.hwndFocus;
        checkedAt=GetTickCount64();
        safe=ok && generation==revision.load() && fg==GetForegroundWindow();
        Sleep(100);
    }
    if(last) last->Release(); if(uia) uia->Release();
    CoUninitialize(); return 0;
}
extern "C" void security_start(void) {
    focusHook=SetWinEventHook(EVENT_OBJECT_FOCUS,EVENT_OBJECT_FOCUS,nullptr,focusChanged,0,0,WINEVENT_OUTOFCONTEXT);
    worker=CreateThread(nullptr,0,monitor,nullptr,0,nullptr);
}
extern "C" int security_safe(unsigned long *generation) {
    *generation=revision.load();
    HWND fg=GetForegroundWindow(); GUITHREADINFO info={sizeof(info)};
    if(!GetGUIThreadInfo(GetWindowThreadProcessId(fg,nullptr),&info)) return 0;
    return safe && GetTickCount64()-checkedAt.load()<500 && fg==foreground && info.hwndFocus==focused;
}
extern "C" void security_stop(void) {
    running=false; if(focusHook) UnhookWinEvent(focusHook);
    // The worker owns COM objects; process shutdown does not wait on a hung provider.
    if(worker) { WaitForSingleObject(worker,200); CloseHandle(worker); }
}
