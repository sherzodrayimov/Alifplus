#ifndef ALIF_CONVERSION_H
#define ALIF_CONVERSION_H
#include <wchar.h>
static int alif_apos(wchar_t c) { return c == L'\'' || c == 0x2018 || c == 0x2019 || c == 0x02bb || c == 0x02bc || c == L'`'; }
static wchar_t alif_pair(wchar_t p, wchar_t c) {
    if (alif_apos(c)) {
        switch (p) { case L'o': return 0xf6; case L'O': return 0xd6; case L'g': return 0x11f; case L'G': return 0x11e; }
    }
    if (c == L'h' || c == L'H') {
        switch (p) { case L's': return 0x15f; case L'S': return 0x15e; case L'c': return 0xe7; case L'C': return 0xc7; }
    }
    return 0;
}
static int alif_letter(wchar_t c) { return (c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z') || c==0xf6 || c==0xd6 || c==0x11f || c==0x11e || c==0x15f || c==0x15e || c==0xe7 || c==0xc7; }
static void alif_convert(const wchar_t *src, wchar_t *dst) {
    size_t i=0, j=0;
    while (src[i]) {
        wchar_t rep=src[i+1] ? alif_pair(src[i],src[i+1]) : 0;
        if (rep) { dst[j++]=rep; i+=2; }
        else { dst[j++]=(alif_apos(src[i]) && i && alif_letter(src[i-1])) ? 0x2019 : src[i]; i++; }
    }
    dst[j]=0;
}
#endif
