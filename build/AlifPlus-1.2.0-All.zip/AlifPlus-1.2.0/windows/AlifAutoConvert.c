#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <wchar.h>
#include <wctype.h>
#include "conversion.h"
void security_start(void);
int security_safe(unsigned long *generation);
void security_stop(void);

#define WM_TRAYICON (WM_USER + 1)
#define ID_TRAY_TOGGLE 1001
#define ID_TRAY_CLIP   1002
#define ID_TRAY_EXIT   1003
#define ID_TRAY_LOGIN  1004

static HHOOK g_hook = NULL;
static BOOL g_enabled = FALSE;
static WCHAR g_undo[3] = {0};
static HHOOK g_mouse;
static unsigned long g_generation;
static BOOL g_ctrl, g_shift, g_chord, g_chordUsed;
static BOOL g_modifiers[256];
static WCHAR g_prevChar = 0;
static NOTIFYICONDATAW g_nid = {0};

static BOOL launch_at_login(void) {
    HKEY key; DWORD bytes=0;
    if(RegOpenKeyExW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",0,KEY_QUERY_VALUE,&key)!=ERROR_SUCCESS) return FALSE;
    LONG result=RegQueryValueExW(key,L"AlifPlusAutoConvert",NULL,NULL,NULL,&bytes);
    RegCloseKey(key); return result==ERROR_SUCCESS && bytes>sizeof(WCHAR);
}
static void toggle_login(HWND hwnd) {
    HKEY key; LONG result=RegCreateKeyExW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",0,NULL,0,KEY_SET_VALUE,NULL,&key,NULL);
    if(result==ERROR_SUCCESS) {
        if(launch_at_login()) result=RegDeleteValueW(key,L"AlifPlusAutoConvert");
        else {
            WCHAR path[MAX_PATH], command[MAX_PATH+3];
            DWORD length=GetModuleFileNameW(NULL,path,MAX_PATH);
            if(!length || length>=MAX_PATH) result=ERROR_INSUFFICIENT_BUFFER;
            else { swprintf_s(command,MAX_PATH+3,L"\"%s\"",path); result=RegSetValueExW(key,L"AlifPlusAutoConvert",0,REG_SZ,(BYTE*)command,(DWORD)((wcslen(command)+1)*sizeof(WCHAR))); }
        }
        RegCloseKey(key);
    }
    if(result!=ERROR_SUCCESS) MessageBoxW(hwnd,L"Avtomatik ishga tushirishni sozlab bo‘lmadi.",L"Alif+",MB_ICONERROR);
}

static void reset_context(void) { g_prevChar=0; g_undo[0]=0; }
static BOOL replace_text(const WCHAR *text, BOOL backspace) {
    INPUT inputs[8]={0}; UINT n=0;
    if(backspace) {
        inputs[n].type=INPUT_KEYBOARD; inputs[n++].ki.wVk=VK_BACK;
        inputs[n].type=INPUT_KEYBOARD; inputs[n].ki.wVk=VK_BACK; inputs[n++].ki.dwFlags=KEYEVENTF_KEYUP;
    }
    for(size_t i=0;text[i] && n+2<=8;i++) {
        inputs[n].type=INPUT_KEYBOARD; inputs[n].ki.wScan=text[i]; inputs[n++].ki.dwFlags=KEYEVENTF_UNICODE;
        inputs[n].type=INPUT_KEYBOARD; inputs[n].ki.wScan=text[i]; inputs[n++].ki.dwFlags=KEYEVENTF_UNICODE|KEYEVENTF_KEYUP;
    }
    return SendInput(n,inputs,sizeof(INPUT))==n;
}
static void update_status(void) {
    unsigned long gen; BOOL available=security_safe(&gen);
    wcscpy_s(g_nid.szTip,128,!g_hook ? L"Alif+ — Kuzatuv xatosi" : !available ? L"Alif+ — Xavfsiz / noma’lum maydon: pauza" : g_enabled ? L"Alif+ — Faol (Ctrl+Shift)" : L"Alif+ — Pauza (Ctrl+Shift)");
    Shell_NotifyIconW(NIM_MODIFY,&g_nid);
}
static void toggle(void) { g_enabled=!g_enabled; reset_context(); update_status(); }
static LRESULT CALLBACK MouseProc(int code,WPARAM w,LPARAM l) {
    if(code==HC_ACTION && (w==WM_LBUTTONDOWN || w==WM_RBUTTONDOWN || w==WM_MBUTTONDOWN || w==WM_MOUSEWHEEL)) reset_context();
    return CallNextHookEx(g_mouse,code,w,l);
}
static void ConvertClipboardText(HWND hwnd) {
    if (!OpenClipboard(hwnd)) return;
    HANDLE hData = GetClipboardData(CF_UNICODETEXT);
    if (hData) {
        LPCWSTR src = (LPCWSTR)GlobalLock(hData);
        if (src) {
            size_t len = wcslen(src);
            HGLOBAL hOut = GlobalAlloc(GMEM_MOVEABLE, (len + 1) * sizeof(WCHAR));
            if (hOut) {
                LPWSTR dst = (LPWSTR)GlobalLock(hOut);
                if (!dst) { GlobalFree(hOut); GlobalUnlock(hData); CloseClipboard(); return; }
                alif_convert(src,dst);
                GlobalUnlock(hOut);
                if (hData) GlobalUnlock(hData);
                hData = NULL;
                if (!EmptyClipboard() || !SetClipboardData(CF_UNICODETEXT, hOut)) GlobalFree(hOut);
            }
            if (hData) GlobalUnlock(hData);
        }
    }
    CloseClipboard();
}

static LRESULT CALLBACK LowLevelKeyboardProc(int code,WPARAM w,LPARAM l) {
    if(code!=HC_ACTION) return CallNextHookEx(g_hook,code,w,l);
    KBDLLHOOKSTRUCT *kb=(KBDLLHOOKSTRUCT*)l;
    if(kb->flags&LLKHF_INJECTED) return CallNextHookEx(g_hook,code,w,l);
    BOOL down=w==WM_KEYDOWN || w==WM_SYSKEYDOWN;
    BOOL ctrlKey=kb->vkCode==VK_CONTROL || kb->vkCode==VK_LCONTROL || kb->vkCode==VK_RCONTROL;
    BOOL shiftKey=kb->vkCode==VK_SHIFT || kb->vkCode==VK_LSHIFT || kb->vkCode==VK_RSHIFT;
    if(ctrlKey || shiftKey) {
        g_modifiers[kb->vkCode]=down;
        g_ctrl=g_modifiers[VK_CONTROL] || g_modifiers[VK_LCONTROL] || g_modifiers[VK_RCONTROL];
        g_shift=g_modifiers[VK_SHIFT] || g_modifiers[VK_LSHIFT] || g_modifiers[VK_RSHIFT];
        BOOL other=(GetAsyncKeyState(VK_MENU)|GetAsyncKeyState(VK_LWIN)|GetAsyncKeyState(VK_RWIN))&0x8000;
        if(g_ctrl && g_shift && !g_chord && !other) { g_chord=TRUE; g_chordUsed=FALSE; }
        if(g_chord && !(g_ctrl && g_shift)) { if(!g_chordUsed) toggle(); g_chord=FALSE; }
        return CallNextHookEx(g_hook,code,w,l);
    }
    if(!down) return CallNextHookEx(g_hook,code,w,l);
    if(g_chord) g_chordUsed=TRUE;
    unsigned long generation=0;
    BOOL safe=security_safe(&generation);
    if(generation!=g_generation) { reset_context(); g_generation=generation; }
    if(!g_enabled || !safe || g_ctrl || (GetAsyncKeyState(VK_MENU)&0x8000) || ((GetAsyncKeyState(VK_LWIN)|GetAsyncKeyState(VK_RWIN))&0x8000)) {
        reset_context(); return CallNextHookEx(g_hook,code,w,l);
    }
    if((kb->vkCode==VK_BACK || kb->vkCode==VK_DELETE) && g_undo[0]) {
        WCHAR original[3]; wcscpy_s(original,3,g_undo); reset_context();
        if(replace_text(original,TRUE)) return 1;
        return CallNextHookEx(g_hook,code,w,l);
    }
    g_undo[0]=0;
    BYTE state[256]={0};
    if(GetAsyncKeyState(VK_SHIFT)&0x8000) state[VK_SHIFT]=0x80;
    state[VK_CAPITAL]=(BYTE)(GetKeyState(VK_CAPITAL)&1);
    WCHAR buf[4]={0};
    HKL layout=GetKeyboardLayout(GetWindowThreadProcessId(GetForegroundWindow(),NULL));
    int rc=ToUnicodeEx(kb->vkCode,kb->scanCode,state,buf,4,4,layout);
    if(rc==1 && buf[0]>=32 && buf[0]!=127) {
        WCHAR ch=buf[0];
        if(kb->vkCode==VK_OEM_7 && !(state[VK_SHIFT]&0x80) && (g_prevChar==L'o' || g_prevChar==L'O' || g_prevChar==L'g' || g_prevChar==L'G')) ch=L'\'';
        WCHAR rep=alif_pair(g_prevChar,ch);
        if(rep) {
            WCHAR text[2]={rep,0}, old=g_prevChar; g_prevChar=0;
            if(replace_text(text,TRUE)) { g_undo[0]=old; g_undo[1]=ch; g_undo[2]=0; return 1; }
        } else if(ch==L'\'' && alif_letter(g_prevChar)) {
            g_prevChar=0;
            if(replace_text(L"’",FALSE)) { g_undo[0]=L'\''; g_undo[1]=0; return 1; }
        } else g_prevChar=alif_letter(ch)?ch:0;
    } else reset_context();
    return CallNextHookEx(g_hook,code,w,l);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (msg == WM_TIMER) { update_status(); return 0; }
    if (msg == WM_TRAYICON && (lParam == WM_RBUTTONUP || lParam == WM_LBUTTONUP)) {
        POINT pt;
        GetCursorPos(&pt);
        HMENU menu = CreatePopupMenu();
        AppendMenuW(menu, MF_STRING | (g_enabled ? MF_CHECKED : 0), ID_TRAY_TOGGLE, L"Avto-o‘girish — Ctrl+Shift");
        AppendMenuW(menu, MF_STRING, ID_TRAY_CLIP, L"Buferdagi (Clipboard) matnni o\x02BBgirish");
        AppendMenuW(menu, MF_STRING | (launch_at_login() ? MF_CHECKED : 0), ID_TRAY_LOGIN, L"Kompyuterga kirganda ishga tushirish");
        AppendMenuW(menu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(menu, MF_STRING, ID_TRAY_EXIT, L"Chiqish");
        SetForegroundWindow(hwnd);
        TrackPopupMenu(menu, TPM_BOTTOMALIGN | TPM_LEFTALIGN, pt.x, pt.y, 0, hwnd, NULL);
        DestroyMenu(menu);
        return 0;
    }
    if (msg == WM_COMMAND) {
        switch (LOWORD(wParam)) {
            case ID_TRAY_TOGGLE:
                toggle();
                break;
            case ID_TRAY_CLIP:
                ConvertClipboardText(hwnd);
                break;
            case ID_TRAY_EXIT:
                PostQuitMessage(0);
                break;
            case ID_TRAY_LOGIN:
                toggle_login(hwnd);
                break;
        }
    }
    if (msg == WM_DESTROY) {
        Shell_NotifyIconW(NIM_DELETE, &g_nid);
        PostQuitMessage(0);
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev, LPWSTR lpCmdLine, int nShow) {
    HANDLE hMutex = CreateMutexW(NULL, TRUE, L"AlifPlusAutoConvertSingleInstance");
    if (GetLastError() == ERROR_ALREADY_EXISTS) return 0;

    WNDCLASSW wc = {0};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = L"AlifPlusAutoConvertWnd";
    RegisterClassW(&wc);

    HWND hwnd = CreateWindowW(wc.lpszClassName, L"Alif+", 0, 0, 0, 0, 0, HWND_MESSAGE, NULL, hInst, NULL);

    g_nid.cbSize = sizeof(NOTIFYICONDATAW);
    g_nid.hWnd = hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_TRAYICON;
    g_nid.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcscpy_s(g_nid.szTip, 128, L"Alif+ — Pauza (Ctrl+Shift)");
    Shell_NotifyIconW(NIM_ADD, &g_nid);

    security_start();
    SetTimer(hwnd,1,500,NULL);
    g_mouse=SetWindowsHookExW(WH_MOUSE_LL,MouseProc,hInst,0);
    g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelKeyboardProc, hInst, 0);
    update_status();
    if(!g_hook || !g_mouse) MessageBoxW(NULL,L"Klaviatura yoki sichqoncha kuzatuvini boshlab bo‘lmadi. Alif+ ni qayta oching.",L"Alif+",MB_ICONERROR);
    if(!g_mouse && g_hook) { UnhookWindowsHookEx(g_hook); g_hook=NULL; update_status(); }

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    security_stop();
    if (g_mouse) UnhookWindowsHookEx(g_mouse);
    if (g_hook) UnhookWindowsHookEx(g_hook);
    if (hMutex) CloseHandle(hMutex);
    return 0;
}
