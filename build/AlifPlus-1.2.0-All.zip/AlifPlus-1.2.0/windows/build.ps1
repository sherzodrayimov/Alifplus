param([Parameter(Mandatory=$true)][ValidateSet('x86','x64')][string]$Arch)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
New-Item -ItemType Directory -Force "build/$Arch" | Out-Null
if ($env:VSCMD_ARG_TGT_ARCH -ne $Arch) { throw "Use the MSVC $Arch Developer Command Prompt." }
& rc /fo "build/$Arch/kbdalif.res" kbdalif.rc
if ($LASTEXITCODE) { throw 'Resource compilation failed' }
& cl /nologo /O2 /GS- /Zl /LD /utf-8 "/Fo:build/$Arch/kbdalif.obj" "/Fe:build/$Arch/kbdalif.dll" kbdalif.c "build/$Arch/kbdalif.res" /link /DEF:kbdalif.def /NOENTRY /NODEFAULTLIB
if ($LASTEXITCODE) { throw 'Keyboard DLL compilation failed' }
& cl /nologo /O2 /MT /utf-8 /c security.cpp "/Fo:build/$Arch/security.obj"
if ($LASTEXITCODE) { throw 'Accessibility monitor compilation failed' }
& cl /nologo /O2 /MT /utf-8 "/Fo:build/$Arch/AlifAutoConvert.obj" "/Fe:build/$Arch/AlifAutoConvert.exe" AlifAutoConvert.c "build/$Arch/security.obj" user32.lib shell32.lib ole32.lib uiautomationcore.lib uuid.lib advapi32.lib /link /SUBSYSTEM:WINDOWS
if ($LASTEXITCODE) { throw 'Helper compilation failed' }
$exports = & dumpbin /exports "build/$Arch/kbdalif.dll"
if ($LASTEXITCODE) { throw 'DLL export check failed' }
if (-not ($exports -match 'KbdLayerDescriptor')) { throw 'Keyboard DLL entry point is missing' }
$headers = & dumpbin /headers "build/$Arch/kbdalif.dll"
if ($LASTEXITCODE) { throw 'DLL architecture check failed' }
$machine = if ($Arch -eq 'x64') { '8664 machine' } else { '14C machine' }
if (-not ($headers -match $machine)) { throw 'Keyboard DLL architecture mismatch' }
& cl /nologo /MT /utf-8 "/Fe:build/$Arch/conversion-test.exe" "/Fo:build/$Arch/conversion-test.obj" ../tests/conversion.c
if ($LASTEXITCODE) { throw 'Conversion test compilation failed' }
& "./build/$Arch/conversion-test.exe"
if ($LASTEXITCODE) { throw 'Conversion tests failed' }
