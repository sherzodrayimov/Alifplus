Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
!include "FileFunc.nsh"
!include "WinVer.nsh"
Name "Alif+ 1.2.0"
OutFile "AlifPlus-1.2.0-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\AlifPlus"
RequestExecutionLevel user
Var Machine
Var Token
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
Function .onInit
    ${IfNot} ${AtLeastWin10}
        MessageBox MB_ICONSTOP "Alif+ uchun Windows 10 (1607+) yoki Windows 11 kerak."
        Abort
    ${EndIf}
    ReadRegStr $0 HKLM "SOFTWARE\Microsoft\Windows NT\CurrentVersion" "CurrentBuildNumber"
    ${If} $0 < 14393
        MessageBox MB_ICONSTOP "Windows 10 ni 1607 yoki yangiroq versiyaga yangilang."
        Abort
    ${EndIf}
    ${If} ${IsNativeARM64}
        MessageBox MB_ICONSTOP "Bu paket Windows x86/x64 uchun. ARM64 qo‘llab-quvvatlanmaydi."
        Abort
    ${EndIf}
    ${GetParameters} $0
    ClearErrors
    ${GetOptions} $0 "/MACHINE=" $Machine
    ${IfNot} ${Errors}
        SetSilent silent
    ${EndIf}
FunctionEnd
Section "Alif+"
    ${If} ${RunningX64}
        SetRegView 64
    ${EndIf}
    ${If} $Machine != ""
        ClearErrors
        ${If} ${RunningX64}
            ${DisableX64FSRedirection}
            SetOutPath "$WINDIR\System32"
            File "build\x64\kbdalif.dll"
            SetOutPath "$WINDIR\SysWOW64"
            File "build\x86\kbdalif.dll"
            ${EnableX64FSRedirection}
        ${Else}
            SetOutPath "$SYSDIR"
            File "build\x86\kbdalif.dll"
        ${EndIf}
        ${If} ${Errors}
            MessageBox MB_ICONSTOP "Klaviatura faylini yozib bo‘lmadi. Alif+ ishlatayotgan dasturlarni yoping va qayta urinib ko‘ring."
            SetErrorLevel 1
            Quit
        ${EndIf}
        WriteRegStr HKLM "SYSTEM\CurrentControlSet\Control\Keyboard Layouts\a0000443" "Layout File" "kbdalif.dll"
        WriteRegStr HKLM "SYSTEM\CurrentControlSet\Control\Keyboard Layouts\a0000443" "Layout Text" "Alif+"
        WriteRegStr HKLM "SYSTEM\CurrentControlSet\Control\Keyboard Layouts\a0000443" "Layout Id" "00C5"
        ${If} ${Errors}
            SetErrorLevel 1
            Quit
        ${EndIf}
        WriteRegStr HKLM "Software\AlifPlus" "InstallToken" "$Machine"
        Quit
    ${EndIf}
    ; Only machine files are elevated. Language and login settings use the original account.
    System::Call 'kernel32::GetTickCount() i .r0'
    StrCpy $Token $0
    ClearErrors
    ExecShellWait "runas" "$EXEPATH" '/MACHINE=$Token' SW_SHOWNORMAL
    ${If} ${Errors}
        MessageBox MB_ICONSTOP "Administrator ruxsati berilmadi. O‘rnatish tugamadi."
        Abort
    ${EndIf}
    ReadRegStr $0 HKLM "Software\AlifPlus" "InstallToken"
    ${If} $0 != $Token
        MessageBox MB_ICONSTOP "Tizim klaviaturasi o‘rnatilmadi. Qayta urinib ko‘ring."
        Abort
    ${EndIf}
    SetOutPath "$INSTDIR"
    nsExec::ExecToLog 'taskkill /F /IM AlifAutoConvert.exe'
    Pop $0
    ClearErrors
    ${If} ${RunningX64}
        File "build\x64\AlifAutoConvert.exe"
    ${Else}
        File "build\x86\AlifAutoConvert.exe"
    ${EndIf}
    File "register.ps1"
    File "unregister.ps1"
    ${If} ${Errors}
        MessageBox MB_ICONSTOP "Ilova fayllarini yozib bo‘lmadi. Alif+ ni yoping va qayta urinib ko‘ring."
        Abort
    ${EndIf}
    nsExec::ExecToLog 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\register.ps1"'
    Pop $0
    ${If} $0 != 0
        MessageBox MB_ICONEXCLAMATION "Til ro‘yxatiga qo‘shish bajarilmadi. Settings → Time & language → Uzbek → Keyboard orqali Alif+ ni qo‘shing."
    ${EndIf}
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "AlifPlusAutoConvert" '"$INSTDIR\AlifAutoConvert.exe"'
    WriteUninstaller "$INSTDIR\uninstall.exe"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AlifPlus" "DisplayName" "Alif+ 1.2.0"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AlifPlus" "UninstallString" '"$INSTDIR\uninstall.exe"'
    Exec '"$INSTDIR\AlifAutoConvert.exe"'
    MessageBox MB_OK "Alif+ o‘rnatildi. Win+Space orqali terilmani tanlang. Avto-o‘girish uchun Ctrl+Shift ni bosib qo‘yib yuboring. Klaviatura ko‘rinmasa, hisobdan chiqib qayta kiring."
SectionEnd
Function un.onInit
    StrCpy $Machine ""
    ${GetParameters} $0
    ${GetOptions} $0 "/MACHINE=" $Machine
    ${If} $Machine != ""
        SetSilent silent
    ${EndIf}
FunctionEnd
Section "Uninstall"
    ${If} ${RunningX64}
        SetRegView 64
    ${EndIf}
    ${If} $Machine != ""
        ClearErrors
        DeleteRegKey HKLM "SYSTEM\CurrentControlSet\Control\Keyboard Layouts\a0000443"
        ${If} ${RunningX64}
            ${DisableX64FSRedirection}
            Delete /REBOOTOK "$WINDIR\System32\kbdalif.dll"
            Delete /REBOOTOK "$WINDIR\SysWOW64\kbdalif.dll"
            ${EnableX64FSRedirection}
        ${Else}
            Delete /REBOOTOK "$SYSDIR\kbdalif.dll"
        ${EndIf}
        ${If} ${Errors}
            SetErrorLevel 1
            Quit
        ${EndIf}
        WriteRegStr HKLM "Software\AlifPlus" "RemoveToken" "$Machine"
        Quit
    ${EndIf}
    nsExec::ExecToLog 'taskkill /F /IM AlifAutoConvert.exe'
    Pop $0
    nsExec::ExecToLog 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\unregister.ps1"'
    Pop $0
    ${If} $0 != 0
        MessageBox MB_ICONEXCLAMATION "Til ro‘yxatini yangilab bo‘lmadi. Settings orqali Alif+ ni olib tashlang va qayta urinib ko‘ring."
        Abort
    ${EndIf}
    System::Call 'kernel32::GetTickCount() i .r0'
    StrCpy $Token $0
    ClearErrors
    ; _?= prevents the elevated uninstaller from spawning a copy and exiting early.
    ExecShellWait "runas" "$EXEPATH" '/MACHINE=$Token _?=$INSTDIR' SW_SHOWNORMAL
    ${If} ${Errors}
        MessageBox MB_ICONEXCLAMATION "Tizim klaviaturasi o‘chirilishi uchun administrator ruxsati kerak."
        Abort
    ${EndIf}
    ReadRegStr $0 HKLM "Software\AlifPlus" "RemoveToken"
    ${If} $0 != $Token
        MessageBox MB_ICONEXCLAMATION "Tizim klaviaturasi o‘chirilmadi. Qayta urinib ko‘ring."
        Abort
    ${EndIf}
    DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "AlifPlusAutoConvert"
    DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AlifPlus"
    Delete "$INSTDIR\AlifAutoConvert.exe"
    Delete "$INSTDIR\register.ps1"
    Delete "$INSTDIR\unregister.ps1"
    Delete "$INSTDIR\uninstall.exe"
    RMDir "$INSTDIR"
    MessageBox MB_OK "Alif+ olib tashlandi. Band klaviatura fayllari o‘chishi uchun kompyuterni qayta ishga tushiring."
SectionEnd
