import Cocoa
let app = NSApplication.shared
app.setActivationPolicy(.accessory)
let delegate = AlifAutoConvertApp()
app.delegate = delegate
app.run()
