import Cocoa
import Carbon
import ServiceManagement

final class AlifAutoConvertApp: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem!
    private var toggleItem: NSMenuItem!
    private var loginItem: NSMenuItem!
    private var enabled = false
    private var eventTap: CFMachPort?
    private var source: CFRunLoopSource?
    private var timer: Timer?
    private var previous: Character?
    private var undo: String?
    private var focus: AXUIElement?
    private var secure = true
    private var chord = false
    private var chordUsed = false
    private var trusted = false
    private let systemWide = AXUIElementCreateSystemWide()
    private let marker: Int64 = 0x414c4946504c5553

    func applicationDidFinishLaunching(_ notification: Notification) {
        // A slow or unavailable accessibility provider must not stall the event tap.
        AXUIElementSetMessagingTimeout(systemWide, 0.03)
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        let menu = NSMenu()
        func item(_ title: String, _ action: Selector) -> NSMenuItem {
            let i = NSMenuItem(title: title, action: action, keyEquivalent: ""); i.target = self; menu.addItem(i); return i
        }
        toggleItem = item("", #selector(toggle))
        _ = item("Ctrl + Shift — yoqish / pauza", #selector(toggle))
        _ = item("Accessibility ruxsatini ochish…", #selector(openPermissions))
        _ = item("Klaviatura sozlamalarini ochish…", #selector(openKeyboardSettings))
        _ = item("O‘rnatish yo‘riqnomasi…", #selector(openGuide))
        _ = item("Buferdagi matnni o‘girish", #selector(convertClipboard))
        loginItem = item("Kompyuterga kirganda ishga tushirish", #selector(toggleLogin))
        menu.addItem(.separator())
        _ = item("Chiqish", #selector(quit))
        statusItem.menu = menu
        let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(opts)
        refresh()
        timer = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: true) { [weak self] _ in self?.refresh() }
        NSWorkspace.shared.notificationCenter.addObserver(self, selector: #selector(resetContext), name: NSWorkspace.didActivateApplicationNotification, object: nil)
    }
    @objc private func resetContext() { previous = nil; undo = nil; focus = nil }
    @objc private func toggle() { enabled.toggle(); resetContext(); refresh() }
    @objc private func quit() { NSApp.terminate(nil) }
    @objc private func openPermissions() {
        NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility")!)
    }
    @objc private func openKeyboardSettings() {
        let address: String
        if #available(macOS 13.0, *) { address = "x-apple.systempreferences:com.apple.Keyboard-Settings.extension" }
        else { address = "x-apple.systempreferences:com.apple.preference.keyboard?InputSources" }
        NSWorkspace.shared.open(URL(string: address)!)
    }
    @objc private func openGuide() {
        if let url = Bundle.main.url(forResource: "Ornatish-yoriqnomasi", withExtension: "html") { NSWorkspace.shared.open(url) }
    }
    @objc private func convertClipboard() {
        let pb = NSPasteboard.general
        if let s = pb.string(forType: .string) { pb.clearContents(); pb.setString(Conversion.full(s), forType: .string) }
    }
    @objc private func toggleLogin() {
        if #available(macOS 13.0, *) {
            do {
                if SMAppService.mainApp.status == .enabled { try SMAppService.mainApp.unregister() }
                else { try SMAppService.mainApp.register() }
            } catch {
                let a = NSAlert(); a.messageText = "Avtomatik ishga tushirishni sozlab bo‘lmadi"; a.informativeText = error.localizedDescription; a.runModal()
            }
        }
        refresh()
    }
    private func refresh() {
        trusted = AXIsProcessTrusted()
        if trusted && eventTap == nil { setupTap() }
        if !trusted { resetContext() }
        let wasSecure = secure
        secure = IsSecureEventInputEnabled()
        if secure != wasSecure { resetContext() }
        let state = !trusted ? "Ruxsat kerak" : eventTap == nil ? "Kuzatuv xatosi" : secure ? "Xavfsiz maydon" : enabled ? "Faol" : "Pauza"
        statusItem.button?.title = "ÖZ " + (trusted && eventTap != nil ? "⇄ " : "⚠ ") + state
        toggleItem.title = (enabled ? "✓ " : "") + "Avto-o‘girish — " + state
        if #available(macOS 13.0, *) { loginItem.state = SMAppService.mainApp.status == .enabled ? .on : .off }
        else { loginItem.isEnabled = false; loginItem.title = "Launch at Login — macOS 13+" }
    }
    private func setupTap() {
        let types: [CGEventType] = [.keyDown, .flagsChanged, .leftMouseDown, .rightMouseDown, .otherMouseDown, .scrollWheel]
        let mask = types.reduce(CGEventMask(0)) { $0 | (1 << $1.rawValue) }
        guard let tap = CGEvent.tapCreate(tap: .cgSessionEventTap, place: .headInsertEventTap, options: .defaultTap, eventsOfInterest: mask, callback: { _, type, event, ctx in
            guard let ctx = ctx else { return Unmanaged.passUnretained(event) }
            return Unmanaged<AlifAutoConvertApp>.fromOpaque(ctx).takeUnretainedValue().handle(type, event)
        }, userInfo: Unmanaged.passUnretained(self).toOpaque()) else { return }
        eventTap = tap
        source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0)
        CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
        CGEvent.tapEnable(tap: tap, enable: true)
    }
    // Fail closed when accessibility cannot establish that the focused control is editable.
    private func safeFocus() -> Bool {
        if IsSecureEventInputEnabled() { resetContext(); return false }
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(systemWide, kAXFocusedUIElementAttribute as CFString, &value) == .success,
              let value = value, CFGetTypeID(value) == AXUIElementGetTypeID() else { resetContext(); return false }
        let element = unsafeBitCast(value, to: AXUIElement.self)
        AXUIElementSetMessagingTimeout(element, 0.03)
        if let old = focus, !CFEqual(old, element) { previous = nil; undo = nil }
        focus = element
        var roleValue: CFTypeRef?, subValue: CFTypeRef?
        _ = AXUIElementCopyAttributeValue(element, kAXRoleAttribute as CFString, &roleValue)
        _ = AXUIElementCopyAttributeValue(element, kAXSubroleAttribute as CFString, &subValue)
        let role = roleValue as? String ?? "", subrole = subValue as? String ?? ""
        guard subrole != "AXSecureTextField", ["AXTextField", "AXTextArea", "AXComboBox"].contains(role) else { previous = nil; undo = nil; return false }
        // A selection means Backspace would remove more than the last typed character.
        var selected: CFTypeRef?
        if AXUIElementCopyAttributeValue(element, kAXSelectedTextRangeAttribute as CFString, &selected) == .success,
           let selected = selected, CFGetTypeID(selected) == AXValueGetTypeID() {
            var range = CFRange()
            if AXValueGetValue(unsafeBitCast(selected, to: AXValue.self), .cfRange, &range), range.length > 0 { previous = nil; undo = nil }
        }
        return true
    }
    private func handle(_ type: CGEventType, _ event: CGEvent) -> Unmanaged<CGEvent>? {
        let pass = Unmanaged.passUnretained(event)
        if event.getIntegerValueField(.eventSourceUserData) == marker { return pass }
        if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
            resetContext(); if let tap = eventTap { CGEvent.tapEnable(tap: tap, enable: true) }; return pass
        }
        let flags = event.flags
        if type == .flagsChanged {
            let both = flags.contains(.maskControl) && flags.contains(.maskShift) && !flags.contains(.maskAlternate) && !flags.contains(.maskCommand)
            if both && !chord { chord = true; chordUsed = false }
            else if !both && chord { if !chordUsed { toggle() }; chord = false }
            return pass
        }
        guard type == .keyDown else { resetContext(); return pass }
        if chord { chordUsed = true }
        guard enabled, trusted, !flags.contains(.maskControl), !flags.contains(.maskCommand), !flags.contains(.maskAlternate), safeFocus() else { previous = nil; undo = nil; return pass }
        let key = event.getIntegerValueField(.keyboardEventKeycode)
        if (key == 51 || key == 117), let original = undo {
            resetContext(); return inject(original, backspaces: 1) ? nil : pass
        }
        undo = nil
        var chars = [UniChar](repeating: 0, count: 4), length = 0
        event.keyboardGetUnicodeString(maxStringLength: 4, actualStringLength: &length, unicodeString: &chars)
        guard length == 1, let scalar = UnicodeScalar(chars[0]), !CharacterSet.controlCharacters.contains(scalar) else { previous = nil; return pass }
        var c = Character(scalar)
        if key == 39, !flags.contains(.maskShift), let p = previous, "oOgG".contains(p) { c = "'" }
        if let p = previous, let rep = Conversion.pair(p, c) {
            previous = nil
            if inject(rep, backspaces: 1) { undo = String(p) + String(c); return nil }
            return pass
        }
        if c == "'", let p = previous, p.isLetter {
            previous = nil
            if inject("’", backspaces: 0) { undo = "'"; return nil }
            return pass
        }
        previous = c.isLetter ? c : nil
        return pass
    }
    private func inject(_ text: String, backspaces: Int) -> Bool {
        let src = CGEventSource(stateID: .privateState)
        var events: [CGEvent] = []
        for _ in 0..<backspaces {
            guard let d = CGEvent(keyboardEventSource: src, virtualKey: 51, keyDown: true), let u = CGEvent(keyboardEventSource: src, virtualKey: 51, keyDown: false) else { return false }
            events += [d,u]
        }
        let utf16 = Array(text.utf16)
        guard let d = CGEvent(keyboardEventSource: src, virtualKey: 0, keyDown: true), let u = CGEvent(keyboardEventSource: src, virtualKey: 0, keyDown: false) else { return false }
        d.keyboardSetUnicodeString(stringLength: utf16.count, unicodeString: utf16)
        u.keyboardSetUnicodeString(stringLength: utf16.count, unicodeString: utf16)
        events += [d,u]
        for e in events { e.flags = []; e.setIntegerValueField(.eventSourceUserData, value: marker); e.post(tap: .cghidEventTap) }
        return true
    }
}
