#!/bin/bash
# Create a genuine compressed UDIF image, including on hosts without disk mounting.
set -euo pipefail
[[ $# == 3 ]] || { echo "Usage: $0 SOURCE_DIR OUTPUT.dmg VOLUME_NAME" >&2; exit 2; }
SOURCE_DIR="$(cd "$1" && pwd)"
mkdir -p "$(dirname "$2")"
OUTPUT_DIR="$(cd "$(dirname "$2")" && pwd)"
OUTPUT="$OUTPUT_DIR/$(basename "$2")"
VOLUME_NAME="$3"
TEMP_DIR="$(mktemp -d "$OUTPUT_DIR/.alif-dmg.XXXXXX")"
trap 'rm -rf "$TEMP_DIR"' EXIT
RESULT="$TEMP_DIR/result.dmg"

if ! hdiutil create -volname "$VOLUME_NAME" -srcfolder "$SOURCE_DIR" -fs HFS+ -format UDZO "$RESULT"; then
    echo "Bevosita yaratish ishlamadi; HFS+ fayl obrazi orqali DMG tayyorlanmoqda."
    rm -f "$RESULT"
    hdiutil makehybrid -hfs -hfs-volume-name "$VOLUME_NAME" \
        -hfs-openfolder "$SOURCE_DIR" -o "$TEMP_DIR/source.dmg" "$SOURCE_DIR"
    hdiutil convert "$TEMP_DIR/source.dmg" -format UDZO -o "$RESULT"
fi
[[ -s "$RESULT" ]] || { echo "DMG yaratilmagan." >&2; exit 1; }
hdiutil verify "$RESULT"
mv -f "$RESULT" "$OUTPUT"
echo "Yaratildi va tekshirildi: $OUTPUT"
