import Foundation

enum Conversion {
    static func isApostrophe(_ c: Character) -> Bool { "'‘’ʻʼ`".contains(c) }
    static func pair(_ p: Character, _ c: Character) -> String? {
        if isApostrophe(c) { return ["o":"ö", "O":"Ö", "g":"ğ", "G":"Ğ"][String(p)] }
        if c == "h" || c == "H" { return ["s":"ş", "S":"Ş", "c":"ç", "C":"Ç"][String(p)] }
        return nil
    }
    static func full(_ text: String) -> String {
        let a = Array(text)
        var result = "", i = 0
        while i < a.count {
            if i+1 < a.count, let r = pair(a[i], a[i+1]) { result += r; i += 2 }
            else { result += isApostrophe(a[i]) && i > 0 && a[i-1].isLetter ? "’" : String(a[i]); i += 1 }
        }
        return result
    }
}
