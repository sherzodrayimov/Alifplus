#!/bin/bash
set -euo pipefail
VERSION="1.2.0"
APP_NAME="Alif+"
DMG_NAME="AlifPlus-${VERSION}.dmg"
STAGE_DIR="build/dmg_stage"
HELPER_APP="$STAGE_DIR/Alif+ Avto-O'girish.app"

cd "$(dirname "$0")/.."
rm -rf build/dmg_stage
mkdir -p build
mkdir -p "$STAGE_DIR"
mkdir -p "$HELPER_APP/Contents/MacOS"
mkdir -p "$HELPER_APP/Contents/Resources"

# Compile Universal macOS Auto-Convert Helper (arm64 + x86_64)
swiftc -O -target arm64-apple-macos12.0 macos/Conversion.swift macos/AlifAutoConvert.swift macos/main.swift -o build/AlifAutoConvert_arm64 -module-cache-path "${TMPDIR:-/tmp}/alif-swift-module-cache" -framework Cocoa -framework Carbon -framework ServiceManagement
swiftc -O -target x86_64-apple-macos12.0 macos/Conversion.swift macos/AlifAutoConvert.swift macos/main.swift -o build/AlifAutoConvert_x86_64 -module-cache-path "${TMPDIR:-/tmp}/alif-swift-module-cache" -framework Cocoa -framework Carbon -framework ServiceManagement
lipo -create -output "$HELPER_APP/Contents/MacOS/AlifAutoConvert" build/AlifAutoConvert_arm64 build/AlifAutoConvert_x86_64

cp "macos/Alif+.bundle/Contents/Resources/Alif+.icns" "$HELPER_APP/Contents/Resources/Alif+.icns"

cat << 'EOF' > "$HELPER_APP/Contents/Info.plist"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>AlifAutoConvert</string>
    <key>CFBundleIdentifier</key>
    <string>uz.alifplus.autoconvert</string>
    <key>CFBundleName</key>
    <string>Alif+ Avto-O'girish</string>
    <key>CFBundleIconFile</key>
    <string>Alif+.icns</string>
    <key>CFBundleShortVersionString</key>
    <string>1.2.0</string>
    <key>CFBundleVersion</key><string>1.2.0</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>LSMinimumSystemVersion</key><string>12.0</string>
    <key>LSUIElement</key>
    <true/>
</dict>
</plist>
EOF

cp -R "macos/Alif+.bundle" "$STAGE_DIR/"
cp "macos/O'rnatish (1-klik).command" "$STAGE_DIR/"
cp "web/macos-install.html" "$STAGE_DIR/Ornatish-yoriqnomasi.html"
cp "web/macos-install.html" "$HELPER_APP/Contents/Resources/Ornatish-yoriqnomasi.html"
chmod +x "$STAGE_DIR/O'rnatish (1-klik).command"
if [[ "${ALIF_SIGN_IDENTITY:--}" == - ]]; then
    codesign --force --sign - "$HELPER_APP"
else
    codesign --force --options runtime --timestamp --sign "$ALIF_SIGN_IDENTITY" "$HELPER_APP"
fi
codesign --verify --deep --strict "$HELPER_APP"
ARCHS="$(lipo -archs "$HELPER_APP/Contents/MacOS/AlifAutoConvert")"
[[ " $ARCHS " == *" arm64 "* && " $ARCHS " == *" x86_64 "* ]] || { echo "Universal binary tekshiruvi bajarilmadi" >&2; exit 1; }

cat << 'EOF' > "$STAGE_DIR/O'qib chiqing.txt"
Alif+ (v1.2.0) — O'zbekcha klaviatura terilmasi + Avto-o'girish

Avval "Ornatish-yoriqnomasi.html" ni oching — internet talab qilinmaydi.
macOS 12+, Apple Silicon yoki Intel. Avtomatik ishga tushirish: macOS 13+.

1. "O'rnatish (1-klik).command" faylini oching. Terminal oynasi ochilishi odatiy.
2. Noma’lum ishlab chiquvchi ogohlantirishi chiqsa, ishonchli nusxa uchun
   System Settings → Privacy & Security → Open Anyway → Open. Qayta oching.
3. Komponentlar faqat sizning hisobingizga o‘rnatiladi. Nusxalash uchun sudo kerak emas.
4. Privacy & Security → Accessibility orqali o‘rnatilgan Alif+ yordamchisiga ruxsat bering.
   Ro‘yxatda bo‘lmasa, + → Cmd+Shift+G → ~/Applications → ilovani tanlang.
5. Keyboard → Text Input → Edit → + → Uzbek yoki Others → Alif+ → Add.
   Ro‘yxatda ko‘rinmasa, ishlaringizni saqlab, hisobdan chiqing va qayta kiring.
6. Menyu satridagi input sources ichidan Alif+ ni tanlang.
7. Yordamchi dastlab pauzada. Ctrl+Shift ni bosib qo‘yib yuboring — “Faol”.
   shahar → şahar, o'zbek → özbek. Darhol Delete/Backspace — asl yozuv.
8. Ixtiyoriy: ÖZ menyusi → Kompyuterga kirganda ishga tushirish. So‘ng DMG’ni eject qiling.

macOS 12: System Preferences → Security & Privacy → Privacy → Accessibility;
klaviatura: System Preferences → Keyboard → Input Sources → +.
Ilovani DMG ichidan alohida ochmang: yordamchi ~/Applications ichidan ishga tushishi kerak.
Bu nusxa ad-hoc imzoli; Apple notarizatsiyasidan o‘tmagan.
Xatolar va olib tashlash tartibi HTML yo‘riqnomada berilgan.

EOF

# ZIP remains usable when disk-image services are unavailable on the build host.
ditto -c -k --sequesterRsrc --keepParent "$STAGE_DIR" "build/AlifPlus-${VERSION}-macOS.zip"
if [[ "${ALIF_ZIP_ONLY:-0}" == 1 ]]; then
    echo "Yaratildi: build/AlifPlus-${VERSION}-macOS.zip (DMG so‘ralmadi)"
    exit 0
fi
bash macos/create_dmg.sh "$STAGE_DIR" "build/${DMG_NAME}" "${APP_NAME} ${VERSION}"
if [[ -n "${ALIF_NOTARY_PROFILE:-}" ]]; then
    xcrun notarytool submit "build/${DMG_NAME}" --keychain-profile "$ALIF_NOTARY_PROFILE" --wait
    xcrun stapler staple "$HELPER_APP"
    xcrun stapler staple "build/${DMG_NAME}"
    ditto -c -k --sequesterRsrc --keepParent "$STAGE_DIR" "build/AlifPlus-${VERSION}-macOS.zip"
fi
echo "Yaratildi: build/${DMG_NAME}"
