# Alif+ 1.2.0

US QWERTY asosidagi o‘zbekcha klaviatura, macOS/Windows avto-o‘girish yordamchisi va matn/hujjat o‘giruvchi sayt.

## Klaviatura tartibi

QWERTY harflari o‘z joyida. Rasmdagi tartib ikkala tizimda ham qo‘llanadi.

| US tugmasi | Oddiy | Shift | Option / AltGr | Option / AltGr + Shift |
|---|---|---|---|---|
| `[` | ö | Ö | `[` | `{` |
| `]` | ğ | Ğ | `]` | `}` |
| `;` | ş | Ş | `;` | `:` |
| `'` | ç | Ç | `'` | `"` |
| Backquote | ’ | ~ | ‘ | Backquote |
| Backslash | ; | : | Backslash | Pipe |
| `,` | , | “ | < | « |
| `.` | . | ” | > | » |

macOS’da Option, Windows’da AltGr ishlatiladi. Caps Lock katta harflarni, Caps Lock + Shift kichik harflarni beradi. Tizim klaviaturasi yordamchisiz ham ishlaydi; parolga kiritiladigan belgilar tanlangan terilmaga bog‘liq.

## Avto-o‘girish

1. Ilova dastlab pauzada turadi. **Ctrl+Shift ni bosib qo‘yib yuboring** — yoqiladi yoki pauzaga o‘tadi.
2. `shahar → şahar`, `o'zbek → özbek`, `g'ayrat → ğayrat`, `chiroy → çiroy`.
3. `O' → Ö`, `G' → Ğ`, `Sh/SH → Ş`, `Ch/CH → Ç`. `0` raqami `O` harfi sifatida olinmaydi.
4. O‘girishdan so‘ng darhol **Backspace/Delete**: masalan, `ş → sh`. Kursor yoki boshqa matn harakatidan keyin Delete odatdagidek ishlaydi.
5. Menyu satri/tray belgisini bosing: yoqish/pauza, buferdagi matnni o‘girish va avtomatik ishga tushirish sozlamalari shu yerda.

Alif+ terilmasida `o`/`g` dan keyingi oddiy apostrof tugmasi yordamchi yoqilganida eski yozuv sifatida talqin qilinadi. Option/AltGr kombinatsiyalari yordamchi tomonidan o‘zgartirilmaydi.

macOS’da Secure Input va xavfsiz maydonlar tekshiriladi. Windows’da UI Automation va oddiy password-control tekshiruvi bor. Xavfsizligi yoki fokusi aniqlanmagan maydonda yordamchi pauza qiladi: ayrim Terminal, o‘yin yoki maxsus muharrirlarda avto-o‘girish ishlamasligi mumkin. Tizim klaviaturasi ishlashda davom etadi. Administrator sifatida ochilgan Windows dasturiga oddiy yordamchi matn yubora olmasligi mumkin.

Inglizcha matn/kod uchun Ctrl+Shift bilan pauzaga qo‘ying. Istisno so‘zlar sayt o‘giruvchisida bor; tizim yordamchisida tilni avtomatik aniqlash yo‘q. Belgilangan matnni global hotkey orqali o‘girish kiritilmagan; menyuda clipboard matnini o‘girish mavjud.

## macOS o‘rnatish

macOS 12+, Apple Silicon/Intel universal ilova. Launch at Login — macOS 13+.

To‘liq, internet talab qilmaydigan yo‘riqnoma: [macOS o‘rnatish bosqichlari](web/macos-install.html). Uning nusxasi DMG ichida `Ornatish-yoriqnomasi.html` nomida va yordamchi ilovaning ÖZ menyusida ham bor.

1. Saytdan **macOS uchun yuklab olish** orqali `AlifPlus-1.2.0.dmg` ni yuklab oling va oching. Finder’da **Alif+ 1.2.0** diski paydo bo‘ladi.
2. Disk ichidagi yo‘riqnomani o‘qing, so‘ng `O'rnatish (1-klik).command` ni oching. Terminal ochilishi odatiy; **Alif+ o‘rnatildi** xabarini kuting. Klaviatura `~/Library/Keyboard Layouts`, yordamchi `~/Applications` ichiga ko‘chiriladi.
3. Noma’lum ishlab chiquvchi sabab bloklansa, ishonchli nusxa uchun **System Settings → Privacy & Security → Open Anyway → Open** orqali tasdiqlang, keyin qayta oching. Nusxalash uchun sudo talab qilinmaydi; macOS ruxsatni tasdiqlash uchun parol/Touch ID so‘rashi mumkin.
4. **Privacy & Security → Accessibility** orqali o‘rnatilgan **Alif+ Avto-O'girish** ga ruxsat bering. Ro‘yxatda bo‘lmasa: **+ → ⌘⇧G → ~/Applications → Alif+ Avto-O'girish.app → Open**. Kuzatuv avtomatik qayta boshlanadi. Yangilashdan keyin eski ruxsat yozuvini olib tashlab, yangi nusxani qayta qo‘shish kerak bo‘lishi mumkin.
5. **Keyboard → Text Input → Edit → + → Uzbek yoki Others → Alif+ → Add**. Ko‘rinmasa, ishlaringizni saqlab, hisobdan chiqing va qayta kiring, so‘ng qayta qo‘shing.
6. Menyu satridagi input source ichidan **Alif+** ni tanlang. TextEdit’da `[ ] ; '` → `ö ğ ş ç` ni sinang.
7. **Ctrl+Shift** ni bosib qo‘yib yuboring: **ÖZ ⇄ Faol**. `shahar → şahar`, `o'zbek → özbek`; darhol **Delete/Backspace** — asl yozuv. Yana Ctrl+Shift — pauza.
8. Ixtiyoriy: ÖZ menyusida **Kompyuterga kirganda ishga tushirish** (macOS 13+). Keyin Finder’da Alif+ diskini **Eject** qiling.

macOS 12 da: **System Preferences → Security & Privacy → Privacy → Accessibility** hamda **System Preferences → Keyboard → Input Sources → +**. ZIP muqobil paketida xuddi shu komponentlar mavjud.

Oldingi `/Library/Keyboard Layouts` yoki `/Applications` nusxalari qolgan bo‘lsa, dublikatni Finder orqali olib tashlang. O‘rnatuvchi to‘liq nusxani vaqtinchalik papkaga ko‘chirib, keyin almashtiradi; oldingi foydalanuvchi nusxasini `.previous` sifatida saqlaydi.

Oddiy yig‘ish **ad-hoc imzoli**, Apple notarizatsiyasidan o‘tmagan. Ad-hoc imzo Gatekeeper ogohlantirishlari yoki Accessibility ruxsatini bekor qilmaydi. O‘rnatuvchi karantin atributini faqat o‘zi o‘rnatayotgan ikki Alif+ komponentidan olib tashlaydi.

Olib tashlash: Launch at Login yoqilgan bo‘lsa o‘chiring; menyudan Chiqish; Alif+ ni input sources ro‘yxatidan o‘chirish; yuqoridagi foydalanuvchi papkalaridan komponentlar va keraksiz `.previous` nusxalarini olib tashlash; hisobdan chiqib qayta kirish.

## Windows o‘rnatish

Windows 10 1607+ yoki Windows 11; **x86 (32-bit) va x64 (64-bit)** uchun bitta NSIS o‘rnatuvchi. ARM64 qo‘llab-quvvatlanmaydi.

1. `AlifPlus-1.2.0-Setup.exe` ni oddiy hisobdan oching va tizim klaviaturasi uchun UAC ruxsatini bering. Til sozlamalari va yordamchi dastlabki foydalanuvchi hisobiga yoziladi.
2. x64 tizimda x64 DLL `System32`, x86 DLL `SysWOW64` ichiga qo‘yiladi; x86 tizimda faqat x86 DLL o‘rnatiladi.
3. **Win+Space** orqali Alif+ ni tanlang. Ko‘rinmasa, hisobdan chiqib qayta kiring.
4. Tray belgisidan holatni ko‘ring, **Ctrl+Shift** bilan yoqing. Windows’da shu birikma til almashtirishga tayinlangan bo‘lsa, Advanced keyboard settings orqali til almashtirish birikmasini o‘zgartiring.
5. Til ro‘yxatiga qo‘shish ishlamasa, o‘rnatuvchi xabar beradi. **Settings → Time & language → Uzbek → Keyboards → Alif+** orqali qo‘shing.

Olib tashlash: Windows Settings → Apps → Alif+. Tizim klaviaturasi uchun UAC talab qilinadi; band DLL fayllari qayta ishga tushirganda o‘chadi. Tizim klaviaturasi boshqa foydalanuvchilarga ham ta’sir qiladi. Eski 1.1.0 nusxa boshqa administrator hisobida autostart yaratgan bo‘lsa, o‘sha hisobdagi yozuvni ham olib tashlang.

## Sayt: matn va hujjat

`index.html` va butun `web/` papkasini birga joylang. **Matn va hujjatni yangi alifboga o‘giring** bo‘limida kirill/lotin matni, DOCX, matnli PDF va UTF-8 TXT brauzerda o‘qiladi; istisno so‘zlar, havolalar va email saqlanadi; natija nusxalanadi yoki haqiqiy DOCX sifatida yuklanadi.

Fayllar serverga yuborilmaydi. Hujjatdan **matn** olinadi: asl maket, rasmlar, sahifa bezagi va jadvallar joylashuvi saqlanmaydi. Skanerlangan PDF uchun OCR yo‘q. Eski `.doc` ni avval Word orqali `.docx` sifatida saqlang. Hisob yoki ilova belgilagan hajm limiti yo‘q; amaliy cheklov brauzer xotirasi va qurilmadir. JSZip/PDF.js lokal yuklanadi; litsenziya bildirishnomalari kutubxona fayllari boshida saqlangan.

HTTP(S) orqali oching; PDF `file://` orqali ishlamasligi mumkin. Lokal sinov: `python3 -m http.server 8000`, keyin `http://localhost:8000`. GitHub Pages: mavjud repository → **Settings → Pages → Deploy from a branch → main / root**.

Yuklab olish tugmalari `v1.2.0` Release ichida fayl mavjudligini tekshiradi. Release yo‘q bo‘lsa xabar, tarmoq/API cheklovida Releases sahifasiga havola chiqadi.

## Kodlar va yig‘ish

- `macos/`: Swift yordamchi, klaviatura bundle, o‘rnatuvchi, universal ilovani yig‘ish va DMG yaratish skriptlari.
- `windows/`: x86/x64 DLL, C yordamchi, C++ xavfsizlik monitori, PowerShell va NSIS.
- `web/`: o‘giruvchi kod, hujjat o‘qish/yozish, uslublar va vendor kutubxonalar.
- `tests/`: konversiya va macOS klaviatura xaritasi tekshiruvlari.
- `.github/workflows/release.yml`: Windows/macOS yig‘ish, veb tekshiruvi va release.

macOS, Xcode Command Line Tools bilan:

```bash
python3 tests/check.py
bash macos/build_dmg.sh
# Disk xizmati yo‘q muhitda faqat o‘rnatiladigan ZIP:
ALIF_ZIP_ONLY=1 bash macos/build_dmg.sh
```

`create_dmg.sh` avval odatiy `hdiutil create` usulini ishlatadi. Disk qurilmasiga ulanish mumkin bo‘lmasa, `makehybrid -hfs` bilan HFS+ obraz yaratib, `hdiutil convert -format UDZO` orqali haqiqiy siqilgan DMG’ga aylantiradi. Natija `hdiutil verify` dan o‘tgandan keyingina tayyor fayl bilan almashtiriladi. Tayyor papkani qayta qadoqlash:

```bash
bash macos/create_dmg.sh build/dmg_stage build/AlifPlus-1.2.0.dmg 'Alif+ 1.2.0'
```

Developer ID va oldindan sozlangan notary profili bilan ommaviy tarqatish:

```bash
ALIF_SIGN_IDENTITY='Developer ID Application: YOUR NAME (TEAMID)' \
ALIF_NOTARY_PROFILE='YOUR_KEYCHAIN_PROFILE' bash macos/build_dmg.sh
```

Windows uchun Visual Studio Build Tools (Desktop development with C++), Windows SDK va NSIS 3.09+ kerak:

```powershell
# x86 Native Tools Command Prompt ichida:
powershell -NoProfile -ExecutionPolicy Bypass -File windows/build.ps1 -Arch x86
# x64 Native Tools Command Prompt ichida:
powershell -NoProfile -ExecutionPolicy Bypass -File windows/build.ps1 -Arch x64
# Ikkala yig‘ishdan keyin repository ildizidan:
& 'C:\Program Files (x86)\NSIS\makensis.exe' windows/installer.nsi
```

Veb tekshiruvi: Node 22+ bilan `node tests/browser-conversion.js`.

GitHub Actions’da **Run workflow** artifactlarni yaratadi. O‘zgarishlar commit/push qilingach `v1.2.0` tegini yuborish release’ni yaratadi. Standart workflow Apple notarizatsiyasi yoki Windows Authenticode sertifikatidan foydalanmaydi.

## Tekshiruv holati

macOS universal ilovasi kompilyatsiya qilindi, ad-hoc imzosi tekshirildi; o‘rnatiladigan **DMG va ZIP yaratildi**. DMG yaxlitligi `hdiutil verify` orqali tasdiqlandi. C, Swift va JavaScript konversiya tekshiruvlari muvaffaqiyatli. Klaviatura xaritasi, plist va shell sintaksisi tekshirildi.

**Windows o‘rnatuvchisi bu Mac muhitida yig‘ilmadi va ishga tushirib sinalmadi.** Kod hamda CI yig‘ish yo‘li tayyorlangan. macOS’da bevosita disk yaratish cheklovi HFS+ obrazini fayl sifatida tayyorlash usuli bilan hal qilindi. Toza Mac’da DMG’ni Finder orqali ochib o‘rnatish alohida amaliy sinov talab qiladi.

Accessibility/UAC ruxsatlari, birinchi klaviatura qo‘shish, haqiqiy muharrirda tez yozish, Delete bilan qaytarish va parol maydonlari toza macOS/Windows hisoblarida amalda tekshirilishi kerak.
